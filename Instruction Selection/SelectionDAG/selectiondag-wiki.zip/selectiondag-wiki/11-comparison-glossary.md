# Selector Comparison and Glossary

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)
- [llvm/lib/Target/AArch64/AArch64InstrFormats.td](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64InstrFormats.td)

</details>
LLVM ships three instruction selectors, and AArch64 supports all of them. They differ in what intermediate form they use and how much of the function they see at once.

## Purpose and Scope

This page compares SelectionDAG with FastISel and GlobalISel, summarises the traversal orders, and defines the vocabulary used across the wiki.

## SelectionDAG, FastISel and GlobalISel

```mermaid
flowchart LR
  IR["LLVM IR"] --> SD["SelectionDAG<br/>DAG per block"]
  IR --> FI["FastISel<br/>direct, backward in block"]
  IR --> GI["GlobalISel<br/>IRTranslator to generic MIR"]
  FI -.->|falls back per instruction| SD
  GI -.->|falls back per function| SD
  SD --> MIR["Selected MIR"]
  FI --> MIR
  GI --> MIR
```

| | SelectionDAG | FastISel | GlobalISel |
| --- | --- | --- | --- |
| Default on AArch64 | `-O1` and above | Exists (`AArch64FastISel`) but only used on request | `-O0` (controlled by `-aarch64-enable-global-isel-at-O`); falls back to SelectionDAG per function |
| Intermediate form | A DAG of `SDNode`s per block | None: emits `MachineInstr`s directly | Generic MIR (`G_ADD`, `G_LOAD`, with low-level types such as `s32`, `<4 x s32>`) |
| Scope | One block | One block, walked backward from the terminator | Whole function |
| Optimisation | `DAGCombiner`, up to four runs | None | Rule-based combiners before and after legalization, written in TableGen (`GICombineRule`) |
| Legalization | Type legalizer, then operation legalizer (+ vector legalizer) | None: gives up on anything it cannot select | One `Legalizer` pass driven by per-opcode `LegalizerInfo` rules |
| Instruction choice | Generated matcher from TableGen patterns | Hand-written plus generated fast selectors for common cases | Generated from the same `Pat` records and `ComplexPattern`s (`GIComplexPatternEquiv`, seen as `gi_ro_Xindexed32` in `AArch64InstrFormats.td`) |
| Register class or bank | Picked during selection from the instruction's operand constraints | Same | A separate `RegBankSelect` pass (general vs FP/SIMD), then instruction selection |
| PHIs | Machine PHIs created ahead of time; operands added per block ([PHI Node Resolution](#phi-resolution)) | Shares the SelectionDAG driver and its PHI machinery | `IRTranslator` creates `G_PHI` directly; no export step is needed because the whole function is visible |
| Failure mode | A `Cannot select` fatal error | Falls back to SelectionDAG for the rest of the block | Falls back to SelectionDAG for the whole function ("Instruction selection used fallback path") |
| Strength | Best code quality, the most mature target coverage | Very fast compile at `-O0` | Faster than SelectionDAG, good cross-block optimisation, still maturing |

The `llc` used for the examples confirmed two of these directly. At `-O0`, `-global-isel-abort=1` produced no error for the example functions, so GlobalISel selected them. At `-O2`, the pass list printed by `-debug-pass=Structure` contains the GlobalISel passes, but the `IRTranslator` immediately marks the function as failed and the `aarch64-isel` pass (the SelectionDAG selector) does the work; `-global-isel-abort=2` reports "Instruction selection used fallback path". FastISel iterates each block backward from the terminator, as `SelectAllBasicBlocks` shows (`for (; BI != Begin; --BI)`).

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:404-418](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L404-L418), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:1656-1971](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L1656-L1971), [llvm/lib/Target/AArch64/AArch64InstrFormats.td:3927-3949](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64InstrFormats.td#L3927-L3949)

## Traversal Orders at a Glance

| Step | Visit order | In one sentence |
| --- | --- | --- |
| Block order | Reverse post-order of the CFG | Predecessors are selected before successors where the CFG allows |
| Build DAG | IR instruction order inside the block | One `visit` per IR instruction, forward |
| DAGCombiner | Worklist, last-in-first-out, seeded in `AllNodes` order | Starts at the root, then descends into operands; every change re-queues the changed node's users |
| Type legalizer | Operands before users | A node is processed once all its operands are |
| Vector legalizer | Operands before users (topological order) | One sweep |
| Operation legalizer | Users before operands, sweeps repeated until nothing new is legalized | Reaches a fixed point because legalization creates new nodes |
| Instruction selection | Root first, single sweep | Users first, so a pattern can absorb its operands |
| Scheduling | Bottom-up list scheduling from the exit node, then reversed | Source-order priority on AArch64 |
| Emission | The scheduled sequence, forward | One `MachineInstr` per machine node |

## Glossary

| Term | Meaning |
| --- | --- |
| **SDNode / SDValue** | A DAG node, and one of its results (node pointer plus result number) |
| **MVT / EVT** | Simple and extended value types (`i32`, `v4i32`; `i7`, `i128`) |
| **Chain** | `MVT::Other` edge that orders side effects; starts at `EntryToken` |
| **Glue** | `MVT::Glue` edge that forces two nodes to be adjacent |
| **ISD node** | Target-independent opcode in the `ISD::` namespace |
| **Target node** | Opcode in the `AArch64ISD::` namespace, still a DAG node |
| **Machine node** | A node whose opcode is an instruction (`AArch64::ADDWrr`), created by selection |
| **Legalization** | Rewriting the DAG so every type and operation is supported by the target |
| **Promote / Expand / Custom / LibCall / Legal** | The five actions a target can register for an operation |
| **LowerOperation / ReplaceNodeResults** | Target hooks called for Custom operations (legal result types and illegal result types respectively) |
| **DAGCombine** | The DAG peephole optimiser; the target hook is `PerformDAGCombine` |
| **PatFrag** | A named TableGen sub-pattern, often with a C++ predicate |
| **ComplexPattern** | A pattern operand matched by a C++ function (addressing modes, shifted operands) |
| **SDNodeXForm** | A C++ transformation applied to a matched constant before it is used |
| **AddedComplexity** | Manual priority bonus for a pattern |
| **Matcher table** | The generated bytecode that `SelectCodeCommon` interprets |
| **Fold** | A pattern absorbing an operand node (needs one use and legality) |
| **SUnit** | A scheduling unit: a machine node or a glued group of them |
| **Export register** | A virtual register used to carry an IR value across blocks |
| **PHINodesToUpdate** | List of `(machine PHI, vreg)` pairs waiting for the block to be emitted |
| **MIR** | Machine IR: `MachineInstr`s in a `MachineFunction`, with virtual registers before allocation |
| **NZCV** | AArch64 condition-flags register, written by `SUBS`, `ADDS`, `ANDS`, read by `CSEL` and `Bcc` |

## Where Do I Look?

| Question | Look at |
| --- | --- |
| Why did my IR instruction become a libcall or a long sequence? | `setOperationAction(...)` for that opcode and type in `AArch64ISelLowering.cpp` ([Operation and Vector Legalization](#op-vector-legalization)) |
| Why did this type change before selection? | `addRegisterClass`, `getTypeAction` ([Type Legalization](#type-legalization)) |
| Which AArch64 instruction does a node become? | The patterns in `AArch64InstrInfo.td` and `AArch64InstrFormats.td`, or a `tryXxx` in `AArch64ISelDAGToDAG.cpp` ([Instruction Selection](#instruction-selection)) |
| Why was an addressing mode not folded? | The `ComplexPattern` function (`SelectAddrModeXRO` and friends) and the one-use rule ([Matcher Interpreter and Folding](#matcher-interpreter)) |
| Why is a `madd` or `ldp` missing right after ISel? | They are formed after selection: MachineCombiner and the load/store optimiser |
| Why do I see a `COPY` for a value that never leaves the block? | Cross-block exports and PHI copies ([PHI Node Resolution](#phi-resolution)) |
| `Cannot select: tN: ...` | A node with no pattern and no custom lowering; check legalization actions first |
| A fold fires too early or too late | Its `CombineLevel` guard, `isBeforeLegalizeOps()` and friends ([DAG Combiner](#dag-combiner)) |
