# Tooling, Debugging and Extending

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp)
- [llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp)
- [llvm/lib/CodeGen/SelectionDAG/ScheduleDAGRRList.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/ScheduleDAGRRList.cpp)
- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/lib/Target/AArch64/AArch64InstrInfo.td](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64InstrInfo.td)

</details>
To see the DAG at each phase you need an `llc` built with assertions: `-debug-only` and the graph viewers exist only in such builds. A release `llc` still gives everything at the MIR level.

## Purpose and Scope

This page lists the `llc` switches that matter for SelectionDAG work, how to read a DAG dump, a debugging recipe for bad code, and the three ways to extend selection: a pattern, a combine and a custom lowering.

## Building an `llc` That Can Print DAGs

```bash
cmake -G Ninja -S llvm -B build -DCMAKE_BUILD_TYPE=Release \
      -DLLVM_ENABLE_ASSERTIONS=ON -DLLVM_TARGETS_TO_BUILD=AArch64
ninja -C build llc llvm-tblgen FileCheck
```

Release with assertions is much faster than a full Debug build and has all the `-debug-only` output.

## Command-Line Switches

| Goal | Switch | Notes |
| --- | --- | --- |
| Print every DAG stage plus the matcher trace | `-debug-only=isel` | Needs assertions. Titles: *Initial selection DAG*, *Optimized lowered selection DAG*, *Type-legalized selection DAG*, *Optimized type-legalized selection DAG*, *Vector-legalized selection DAG*, *Vector/type-legalized selection DAG*, *Optimized vector-legalized selection DAG*, *Legalized selection DAG*, *Optimized legalized selection DAG*, *Selected selection DAG* |
| Print only the DAG dumps | `-debug-only=isel-dump` | `ISEL_DUMP_DEBUG_TYPE` is `DEBUG_TYPE "-dump"` |
| One block only | `-filter-view-dags=<block name>` | Also limits the graph viewers |
| Draw a stage as a graph (needs Graphviz) | `-view-dag-combine1-dags`, `-view-legalize-types-dags`, `-view-dag-combine-lt-dags`, `-view-legalize-dags`, `-view-dag-combine2-dags`, `-view-isel-dags`, `-view-sched-dags`, `-view-sunit-dags` | One per phase |
| Sort nodes in dumps | `-dump-sorted-dags` | Topological order, easier to diff |
| Stop after instruction selection and print MIR | `-stop-after=finalize-isel` | Works in release builds; also `-stop-before=...`, `-print-after-all` |
| Show the pass pipeline | `-debug-pass=Structure` | Find `aarch64-isel`, `finalize-isel`, `phi-node-elimination`, `register-coalescer` |
| Pick the selector | `-global-isel=0` / `1`, `-fast-isel`, `-O0`..`-O3` | At `-O0` AArch64 uses GlobalISel by default, with SelectionDAG fallback |
| Pick the DAG scheduler | `-pre-RA-sched=source`, `list-burr`, `list-ilp`, `list-hybrid`, `fast`, `linearize` | See [Scheduling and MIR Emission](#scheduling-emission) |
| Disable the generic combiner | `-combiner-disabled` | Quick check whether a miscompile comes from a combine |
| Bisect combines | `-debug-counter=dagcombine-skip=N,dagcombine-count=M` | Needs assertions; `DAGCombiner::combine` checks the counter |
| Features that change legality | `-mattr=+cssc`, `-mcpu=...` | Changes `setOperationAction` results |
| Make fallbacks loud | `-global-isel-abort=1`, `-fast-isel-abort=1` | Turns silent fallbacks into errors |

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:118](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L118), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:130](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L130), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:149-182](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L149-L182), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:219](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L219), [llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp:98](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp#L98), [llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp:157-160](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp#L157-L160), [llvm/lib/CodeGen/SelectionDAG/ScheduleDAGRRList.cpp:70-87](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/ScheduleDAGRRList.cpp#L70-L87)

## Reading a DAG Dump

```text
t0: ch,glue = EntryToken
t2: i64,ch = CopyFromReg t0, Register:i64 %0
t4: i32 = truncate t2
t5: i32 = add nsw t4, Constant:i32<1>
t6: ch = store<(store (s32) into %ir.p)> t0, t5, t2, undef:i64
```

- `tN` is a node, printed as `result types = opcode operands`; `t2:1` names result 1 of `t2`.
- `ch` is a chain (`MVT::Other`), `glue` is a glue edge, others are data types.
- Flags such as `nsw` follow the opcode; the `<...>` after `load` or `store` is its memory operand.
- `Constant:i32<1>` is an `ISD::Constant`; `TargetConstant:i32<1>` is a final immediate.
- `undef` as the offset of a load or store is the unindexed placeholder.

## Debugging Recipe for Bad Code

```mermaid
flowchart TD
  A["Reduce to a small .ll"] --> B["llc -O2 -stop-after=finalize-isel"]
  B --> C{"MIR as expected?"}
  C -- yes --> L["Look at later MIR passes<br/>print-after-all, find the first change"]
  C -- no --> D["Assertion build: -debug-only=isel-dump"]
  D --> E["Read Optimized legalized selection DAG"]
  E --> F{"DAG shape already wrong?"}
  F -- yes --> G["Compare consecutive dumps,<br/>find the combine or legalization"]
  F -- no --> H["Wrong instruction chosen:<br/>search .td patterns and AddedComplexity,<br/>read the isel matcher trace"]
```

## Adding Behaviour: Three Recipes

**A new instruction pattern** (selection only). Add a `Pat` next to similar ones in `AArch64InstrInfo.td` with a sensible `AddedComplexity`, then rebuild. The shape, from the existing file:

```text
def : Pat<(i32 (mul GPR32:$Rn, GPR32:$Rm)),
          (MADDWrrr GPR32:$Rn, GPR32:$Rm, WZR)>;
```

The build regenerates `AArch64GenDAGISel.inc`; its `// Src:` and `// Dst:` comments show how the pattern was placed in the decision tree.

**A new DAG combine** (optimisation). Register interest in the constructor with `setTargetDAGCombine(ISD::XYZ)`, add `case ISD::XYZ: return performXYZCombine(N, DCI, DAG);` in `AArch64TargetLowering::PerformDAGCombine`, and write the function using `DCI.isBeforeLegalize()`, `isBeforeLegalizeOps()` and `DAG.getNode(...)`. Always check legality when the level is past legalization, and make sure the replacement does not match your own fold again.

**A new custom lowering** (a generic node the target cannot select). Call `setOperationAction(ISD::FOO, MVT::i32, Custom)` in the constructor, add `case ISD::FOO: return LowerFOO(Op, DAG);` in `LowerOperation`, build target nodes there (for example an `AArch64ISD::BAR` declared by an `SDNode<"AArch64ISD::BAR", ...>` record in the `.td` files) and add a `Pat` that maps `AArch64bar` to the machine instruction. If the result type is illegal, implement `ReplaceNodeResults` instead.

**Sources:** [llvm/lib/Target/AArch64/AArch64InstrInfo.td:2911-2921](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64InstrInfo.td#L2911-L2921), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:30803-31168](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L30803-L31168), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:8432-8850](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L8432-L8850)

## Tests

Backend tests live in `llvm/test/CodeGen/AArch64/` and look like `; RUN: llc < %s -mtriple=aarch64 | FileCheck %s`. The script `llvm/utils/update_llc_test_checks.py` regenerates the `CHECK` lines. For MIR-level tests use `-stop-after`, `-run-pass`, or `llvm/utils/update_mir_test_checks.py`.
