# AArch64 Walkthroughs

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp)
- [llvm/lib/Target/AArch64/AArch64InstrInfo.td](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64InstrInfo.td)
- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp)

</details>
This section applies the earlier pages to concrete AArch64 code: arithmetic, data movement, memory, control flow, calls, and one function traced through every phase.

## Purpose and Scope

Each child page has the same layout: the IR, what the DAG phases did, the MIR after instruction selection, and the final assembly. The MIR and assembly are real output from `llc`; the DAGs between phases are reconstructed from the algorithms documented on the earlier pages, because the available `llc` is a release build without `-debug-only=isel`.

| Page | Covers |
| --- | --- |
| [Arithmetic and Data Movement](#arith-data) | Add, multiply, divide by constant, `i128`, vectors, floating point, constants, copies, extensions, global addresses |
| [Memory Instructions](#memory) | Addressing modes, indexed loads, store forms, `ldp`/`stp` pairing, chain ordering |
| [Control Flow and Calls](#control-flow-calls) | Compare and branch, `select`, calls, returns |
| [End-to-End Example](#end-to-end) | One function through all eight phases, plus the `-O0` contrast |

## How the Examples Were Produced

| Item | Value |
| --- | --- |
| Compiler | `llc` LLVM 23.1.4 (optimised build, no assertions), `-mtriple=aarch64 -O2` |
| MIR after selection | `-stop-after=finalize-isel` |
| MIR after PHI elimination or coalescing | `-stop-after=phi-node-elimination`, `-stop-after=register-coalescer` |
| Source citations | Pinned to the `llvmorg-23.1.4` release commit, so cited code matches the measured output |
| Reconstructed DAGs | Written in `-debug-only=isel` format; node numbers are illustrative |

## Reading Real MIR

```mermaid
flowchart LR
  A["IR instruction"] --> B["DAG nodes<br/>ISD and AArch64ISD"]
  B --> C["Machine nodes<br/>AArch64::ADDWrr"]
  C --> D["MachineInstr in MIR<br/>virtual registers"]
  D --> E["Assembly after register allocation<br/>and pseudo expansion"]
```

- `%0:gpr32` is a virtual register of class `gpr32`; `gpr64common` excludes `xzr`; `gpr32all` and `gpr64all` are the loosest classes.
- `$w0`, `$x0`, `$wzr` and `$nzcv` are physical registers.
- Condition codes in `Bcc` and `CSEL` are numeric: `0` = EQ, `1` = NE, `10` = GE, `11` = LT, `12` = GT, `13` = LE.
- Pseudos such as `MOVi32imm`, `MOVaddr`, `LOADgot` and `RET_ReallyLR` are expanded after register allocation, which is why the assembly can differ from the MIR.
