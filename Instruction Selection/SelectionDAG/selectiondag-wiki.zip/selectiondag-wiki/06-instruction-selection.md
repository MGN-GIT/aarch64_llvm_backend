# Instruction Selection

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp)
- [llvm/include/llvm/CodeGen/SelectionDAGISel.h](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGISel.h)
- [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp)

</details>
Instruction selection replaces each remaining generic or `AArch64ISD::` node with machine nodes by matching small trees of nodes against patterns written in TableGen. It works from the root of the DAG toward the leaves and chooses greedily: at each root the first matching pattern, in a fixed priority order, wins.

## Purpose and Scope

This page covers the traversal and the per-node dispatch of `DoInstructionSelection`. The pattern language and the build-time generator are on [TableGen Pattern Language](#pattern-language); the interpreter that runs the generated matcher and the folding rules are on [Matcher Interpreter and Folding](#matcher-interpreter); AArch64's hand-written parts are on [AArch64 Instruction Selection](#aarch64-selection).

## Traversal: Root First

`SelectionDAGISel::DoInstructionSelection` does the following (verified in `SelectionDAGISel.cpp`):

```mermaid
flowchart TD
  A["PreprocessISelDAG"] --> B["AssignTopologicalOrder<br/>number every node"]
  B --> C["HandleSDNode keeps the root alive"]
  C --> D["Start at the last node of AllNodes, the root"]
  D --> E{"Node has users?"}
  E -- no --> F["Skip, it is dead"]
  E -- yes --> G["Select of Node"]
  F --> H{"More nodes toward the entry?"}
  G --> H
  H -- yes --> D
  H -- no --> I["PostprocessISelDAG"]
```

1. `PreprocessISelDAG()`: an optional target hook.
2. `CurDAG->AssignTopologicalOrder()`: number every node so operands have smaller ids than users.
3. Walk `AllNodes` backward from the root to `EntryToken`. Skip a node with no users (dead; nodes folded into an earlier selection become dead this way), lower strict-FP nodes to plain ones if the target lacks them, then call `Select(Node)`.
4. `PostprocessISelDAG()`: another optional hook.

The backward order is deliberate. When `add` is selected first, its operand `shl` is still a generic node, so the pattern `add x, (shl y, 3)` can see it and absorb it into a single `ADDWrs`. If operands were selected first, the `shl` would already be a separate `UBFM` instruction. An `ISelUpdater` keeps the iterator valid while nodes are deleted or replaced, and node ids are a safety net: a selected node gets id `-1`, and the code asserts that no unselected node has a selected predecessor.

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:1287-1392](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L1287-L1392), [llvm/include/llvm/CodeGen/SelectionDAGISel.h:143](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/SelectionDAGISel.h#L143)

## Per-Node Dispatch

`AArch64DAGToDAGISel::Select(SDNode *Node)` runs three tiers:

```mermaid
flowchart TD
  N["Select of Node"] --> M{"Already a machine node?"}
  M -- yes --> M1["Mark selected, done"]
  M -- no --> S{"Opcode handled in the C++ switch?"}
  S -- yes --> T["tryXxx helper"]
  T --> TR{"Helper succeeded?"}
  TR -- yes --> DONE["Replaced, done"]
  TR -- no --> G
  S -- no --> G["SelectCode of Node<br/>generated matcher"]
  G --> GM{"Pattern matched?"}
  GM -- yes --> DONE
  GM -- no --> ERR["Cannot select error"]
```

1. **Already machine?** If `Node->isMachineOpcode()`, the node was created pre-selected, so it is marked done.
2. **Hand-written selection** in a C++ `switch` for cases the pattern language cannot express well: `ISD::LOAD` calls `tryIndexedLoad`; `SRL`, `AND`, `SRA`, `SIGN_EXTEND_INREG` try `tryBitfieldExtractOp`; `OR` tries `tryBitfieldInsertOp`; atomics, system registers, `EXTRACT_SUBVECTOR` and NEON/SVE load-store intrinsics have their own helpers.
3. **Generated matcher.** Anything left goes to `SelectCode(Node)` at the end of the switch.

`SelectCodeCommon` first accepts, without patterns, node kinds that are already in final form: `EntryToken`, `Register`, `CopyFromReg`, `CopyToReg`, `TokenFactor`, `TargetConstant`, `TargetGlobalAddress`, `BasicBlock` and similar. It turns `UNDEF` into `IMPLICIT_DEF` and handles `INLINEASM` specially.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp:5096-5173](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp#L5096-L5173), [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp:7754](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp#L7754), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:3354-3443](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L3354-L3443)

## What Selection Produces

When the backward sweep ends the DAG consists of machine nodes plus the structural nodes (`CopyToReg`, `CopyFromReg`, `TokenFactor`, `EntryToken`). `-debug-only=isel` prints it as *Selected selection DAG*. It is still a graph: nothing says in which order independent instructions must appear. That is the scheduler's job; see [Scheduling and MIR Emission](#scheduling-emission).

## Not Everything Is Decided Here

Some familiar AArch64 optimisations are not SelectionDAG decisions. In real output the fused multiply-add and load/store pairs appear only later:

- `a*b + c` is selected as `MADDWrrr %0, %1, $wzr` (a plain multiply) followed by `ADDWrr`. The MachineCombiner pass later fuses them into `madd w0, w0, w1, w2`. The source of `performMulCombine` says so in a comment: "in MachineCombiner pass, add+mul will be combined into madd".
- Two adjacent `LDRXui` become `ldp` (and two `STRXui` become `stp`) in `AArch64LoadStoreOptimizer`, after register allocation.

The split is intentional: those fusions depend on register pressure, scheduling and pairing rules that the DAG cannot see.

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:21215-21217](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L21215-L21217), [llvm/lib/Target/AArch64/AArch64InstrInfo.td:2911-2921](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64InstrInfo.td#L2911-L2921)
