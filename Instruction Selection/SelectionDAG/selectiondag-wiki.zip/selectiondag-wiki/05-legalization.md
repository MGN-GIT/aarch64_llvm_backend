# Legalization

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/SelectionDAG/LegalizeTypes.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeTypes.cpp)
- [llvm/lib/CodeGen/SelectionDAG/LegalizeDAG.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeDAG.cpp)
- [llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp)
- [llvm/include/llvm/CodeGen/TargetLowering.h](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/TargetLowering.h)
- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)

</details>
Legalization rewrites the DAG so that every value has a type the target keeps in a register and every operation is one the target can select. It is split into three components that run in a fixed order, with combine runs in between.

## Purpose and Scope

This page is the overview of legalization: what the three legalizers are, how the target describes what it supports, and how they interact. The detail is on [Type Legalization](#type-legalization) and [Operation and Vector Legalization](#op-vector-legalization).

## The Three Legalizers

```mermaid
flowchart LR
  A["DAG after Combine 1<br/>any type, any operation"] --> T["DAGTypeLegalizer<br/>types become legal"]
  T --> C2["Combine 2<br/>if changed"]
  C2 --> V["VectorLegalizer<br/>vector operations supported"]
  V --> T2["DAGTypeLegalizer again<br/>if vectors changed"]
  T2 --> C3["Combine 3"]
  C3 --> O["SelectionDAGLegalize<br/>operations legal or Custom"]
  O --> C4["Combine 4"]
```

| Legalizer | Entry point | Question it answers | Mechanism |
| --- | --- | --- | --- |
| Type legalizer | `SelectionDAG::LegalizeTypes()` calling `DAGTypeLegalizer::run` | Can this value live in a register? | Promote, expand, soften, scalarize, split, widen |
| Vector legalizer | `SelectionDAG::LegalizeVectors()` calling `VectorLegalizer::Run` | Does the target have this vector operation? | Promote, Custom, Expand (often by unrolling) |
| Operation legalizer | `SelectionDAG::Legalize()` calling `SelectionDAGLegalize` | Does the target have this operation on this type? | Legal, Custom, Expand, LibCall, Promote |

**Sources:** [llvm/lib/CodeGen/SelectionDAG/LegalizeTypes.cpp:200-487](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeTypes.cpp#L200-L487), [llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp:207-247](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp#L207-L247), [llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp:2513-2515](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp#L2513-L2515), [llvm/lib/CodeGen/SelectionDAG/LegalizeDAG.cpp:6328-6375](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeDAG.cpp#L6328-L6375)

## How a Target Declares Support

Everything is declared in the `AArch64TargetLowering` constructor and read back by the generic code through `TargetLowering` queries.

| Declaration | Meaning | Read back with |
| --- | --- | --- |
| `addRegisterClass(MVT, RegClass)` then `computeRegisterProperties` | Which types are legal, and the type action for every other type | `getTypeAction`, `getTypeToTransformTo` |
| `setOperationAction(ISD::OP, MVT, Action)` | The action for an opcode on a type | `getOperationAction`, `isOperationLegal`, `isOperationLegalOrCustom` |
| `setLoadExtAction`, `setTruncStoreAction`, `setCondCodeAction` | Extending loads, truncating stores, condition codes | matching getters |
| `setIndexedLoadAction`, `setIndexedStoreAction` | Pre/post-increment addressing | `isIndexedLoadLegal` |
| `setTargetDAGCombine(ISD::OP)` | Opcodes the target wants in `PerformDAGCombine` | `hasTargetDAGCombine` |
| `setBooleanContents(...)` | What a boolean looks like in a register | `getBooleanContents` |

The five actions of `TargetLowering::LegalizeAction` are:

| Action | Meaning |
| --- | --- |
| `Legal` | The target supports the operation natively |
| `Promote` | Execute the operation in a larger type |
| `Expand` | Rewrite using other operations; fall back to a libcall if impossible |
| `LibCall` | Always use a library call |
| `Custom` | Call the target's `LowerOperation` hook |

**Sources:** [llvm/include/llvm/CodeGen/TargetLowering.h:221-242](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/TargetLowering.h#L221-L242), [llvm/include/llvm/CodeGen/TargetLowering.h:1312](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/TargetLowering.h#L1312), [llvm/include/llvm/CodeGen/TargetLowering.h:2713-2740](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/TargetLowering.h#L2713-L2740), [llvm/include/llvm/CodeGen/TargetLowering.h:2918](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/include/llvm/CodeGen/TargetLowering.h#L2918), [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:460-554](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L460-L554)

## Division of Labour

Type legalization changes *types* and does not care whether an operation exists for the new type: `i32 = ctlz t2` stays as it is even if the target has no count-leading-zeros instruction. Whether the operation is legal for its (now legal) type is the job of the operation legalizer. The one overlap is that type-legalization handlers sometimes build a different, equivalent operation (such as `uaddo` plus `uaddo_carry` when expanding an `i128` add), which operation legalization then checks in turn.

After the last combine, `SelectionDAGISel::ComputeLiveOutVRegInfo` records known-bits and sign-bit facts for integer values copied to virtual registers, which later blocks use to simplify their own DAGs. After that the DAG contains only operations the instruction selector can match.

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:910-945](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L910-L945)
