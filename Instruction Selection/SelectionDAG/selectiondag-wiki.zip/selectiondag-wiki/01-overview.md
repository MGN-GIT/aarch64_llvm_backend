# SelectionDAG Overview

<details>
<summary>Relevant source files</summary>

The following files were used as context for generating this wiki page:

- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp)
- [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp)
- [llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp)
- [llvm/lib/CodeGen/SelectionDAG/LegalizeTypes.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeTypes.cpp)
- [llvm/lib/CodeGen/SelectionDAG/LegalizeDAG.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeDAG.cpp)
- [llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp)
- [llvm/lib/CodeGen/SelectionDAG/ScheduleDAGSDNodes.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/ScheduleDAGSDNodes.cpp)
- [llvm/lib/CodeGen/SelectionDAG/InstrEmitter.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/InstrEmitter.cpp)
- [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp)
- [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp)
- [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp)

</details>
SelectionDAG is the LLVM instruction selector that turns one basic block of target-independent LLVM IR into target machine instructions. It first builds a directed acyclic graph of operations for the block, then rewrites that graph in stages until every node is a real target instruction, and finally flattens the graph into a linear list of `MachineInstr`s.

## Purpose and Scope

This wiki explains the SelectionDAG instruction selector in `llvm/lib/CodeGen/SelectionDAG/`, using the AArch64 backend (`llvm/lib/Target/AArch64/`) as the worked example. It covers the data structures, every phase from DAG construction to MIR emission, the TableGen pattern matcher, and how PHI nodes are resolved.

It does not cover GlobalISel or FastISel in depth; see [Selector Comparison and Glossary](#comparison-glossary) for how they differ.

## Where SelectionDAG Fits

SelectionDAG runs once per function, after the IR-level code generation preparation passes and before any machine-level optimisation. Its output is MIR in SSA form: `MachineBasicBlock`s holding `MachineInstr`s in linear order that use virtual registers, with `PHI` instructions still present.

```mermaid
flowchart LR
  IR["LLVM IR<br/>Function in SSA form"] --> PREP["IR passes<br/>CodeGenPrepare, LSR, AtomicExpand"]
  PREP --> ISEL["Instruction selection<br/>SelectionDAGISel"]
  ISEL --> MIR["MachineFunction<br/>SSA MIR, virtual registers, PHIs"]
  MIR --> PRE["Pre-RA MIR passes<br/>machine-combiner, CSE, LICM"]
  PRE --> PHIE["PHIElimination<br/>TwoAddressInstruction"]
  PHIE --> RA["Register allocation"]
  RA --> POST["Frame lowering, ldst-opt,<br/>post-RA passes"]
  POST --> MC["AsmPrinter and MC layer"]
```

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:947-1200](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L947-L1200), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:766-776](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L766-L776)

## Inputs, Outputs and Unit of Work

| | Description |
| --- | --- |
| Input | One LLVM IR `Function` in SSA form, already cleaned by IR passes such as `CodeGenPrepare` |
| Output | A `MachineFunction` whose blocks hold `MachineInstr`s in linear order, using virtual registers (MIR before register allocation) |
| Unit of work | One IR basic block at a time. One IR block can become several machine blocks (switch lowering, stack-protector checks), and with FastISel enabled the DAG covers only the tail that FastISel could not select |
| Cross-block values | Never DAG edges. They travel through virtual registers using `CopyToReg` and `CopyFromReg` nodes |

`SelectionDAGISel::SelectAllBasicBlocks` walks the function's blocks in reverse post-order and calls `SelectBasicBlock` for each, which builds the DAG and runs the phases in `CodeGenAndEmitDAG`.

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:1656-1971](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L1656-L1971), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:884-908](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L884-L908)

## Component Map

| Component | Class or function | File | Role |
| --- | --- | --- | --- |
| Driver | `SelectionDAGISel`, `CodeGenAndEmitDAG` | `SelectionDAGISel.cpp` | Runs the phases for each block |
| IR to DAG | `SelectionDAGBuilder::visit*` | `SelectionDAGBuilder.cpp` | One visitor per IR instruction |
| Optimiser | `DAGCombiner::Run` | `DAGCombiner.cpp` | Worklist peephole optimiser, run up to four times |
| Type legalizer | `DAGTypeLegalizer::run` | `LegalizeTypes.cpp` and siblings | Promote, expand, split, widen types |
| Operation legalizer | `SelectionDAG::Legalize`, `SelectionDAGLegalize` | `LegalizeDAG.cpp` | Legal, Custom, Expand, LibCall, Promote |
| Vector legalizer | `VectorLegalizer::Run` | `LegalizeVectorOps.cpp` | Make vector operations supported |
| Matcher | `SelectCodeCommon` plus generated tables | `SelectionDAGISel.cpp`, `AArch64GenDAGISel.inc` | Pattern matching and node creation |
| Scheduler | `ScheduleDAGRRList` and friends | `ScheduleDAGRRList.cpp` | Order machine nodes |
| Emitter | `InstrEmitter` | `InstrEmitter.cpp` | Create `MachineInstr`s and virtual registers |

**Sources:** [llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp:947-1200](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGISel.cpp#L947-L1200), [llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp:1372-1418](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp#L1372-L1418), [llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp:1846-1963](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/DAGCombiner.cpp#L1846-L1963), [llvm/lib/CodeGen/SelectionDAG/LegalizeTypes.cpp:200-487](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeTypes.cpp#L200-L487), [llvm/lib/CodeGen/SelectionDAG/LegalizeDAG.cpp:6328-6375](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeDAG.cpp#L6328-L6375), [llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp:207-247](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/LegalizeVectorOps.cpp#L207-L247), [llvm/lib/CodeGen/SelectionDAG/ScheduleDAGSDNodes.cpp:848-1093](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/CodeGen/SelectionDAG/ScheduleDAGSDNodes.cpp#L848-L1093)

## AArch64 Components

| Role | Class or file | What it provides |
| --- | --- | --- |
| Lowering | `AArch64TargetLowering` in `AArch64ISelLowering.cpp` | Legal types and operations (`setOperationAction`), `LowerOperation`, `ReplaceNodeResults`, `PerformDAGCombine`, argument, call and return lowering |
| Selector | `AArch64DAGToDAGISel` in `AArch64ISelDAGToDAG.cpp` | Custom `Select`, `ComplexPattern` implementations, `tryIndexedLoad`, `tryBitfieldExtractOp` |
| Patterns | `AArch64InstrInfo.td`, `AArch64InstrFormats.td` | Instruction definitions with embedded patterns, standalone `Pat<>` records, `AArch64ISD::` node definitions |
| Node info | `AArch64SelectionDAGInfo.h` | In current LLVM the `AArch64ISD::` enum is generated into `AArch64GenSDNodeInfo.inc` from the `SDNode` records; older releases declare it by hand |

**Sources:** [llvm/lib/Target/AArch64/AArch64ISelLowering.cpp:460-554](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelLowering.cpp#L460-L554), [llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp:5096-5173](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64ISelDAGToDAG.cpp#L5096-L5173), [llvm/lib/Target/AArch64/AArch64SelectionDAGInfo.h:10-25](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64SelectionDAGInfo.h#L10-L25)

## Which Selector Runs on AArch64

On AArch64 the selector depends on the optimisation level. `AArch64TargetMachine` enables GlobalISel when the optimisation level is at or below `-aarch64-enable-global-isel-at-O` (default 0, so `-O0`), and otherwise the pipeline uses SelectionDAG through `AArch64PassConfig::addInstSelector`, which adds the `AArch64ISelDag` pass.

Observed with `llc` 23.1.4 (`-debug-pass=Structure`): at `-O2` the pass list contains the GlobalISel passes (`IRTranslator`, `Legalizer`, `RegBankSelect`, `InstructionSelect`) followed by `AArch64 Instruction Selection`, but the `IRTranslator` immediately marks the function as failed, so the SelectionDAG pass does the work and `-global-isel-abort=2` reports "Instruction selection used fallback path". At `-O0`, `-global-isel-abort=1` produces no error, so GlobalISel selects the function.

**Sources:** [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:159-162](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L159-L162), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:404-418](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L404-L418), [llvm/lib/Target/AArch64/AArch64TargetMachine.cpp:766-776](https://github.com/llvm/llvm-project/blob/7a941dfb2877a0b8cf30323fefa85ad019e0b0f5/llvm/lib/Target/AArch64/AArch64TargetMachine.cpp#L766-L776)

## The Phases in Brief

| # | Phase | Result | Page |
| --- | --- | --- | --- |
| 1 | Build the DAG from IR | Generic `ISD::` nodes, any type | [DAG Construction](#dag-construction) |
| 2 | DAG Combine 1 | Simplified DAG | [DAG Combiner](#dag-combiner) |
| 3 | Type legalization (then Combine 2) | Every value type is legal | [Type Legalization](#type-legalization) |
| 4 | Vector legalization (then types and Combine 3 if it changed anything) | Vector operations supported | [Operation and Vector Legalization](#op-vector-legalization) |
| 5 | Operation legalization | Every operation Legal or custom-lowered | [Operation and Vector Legalization](#op-vector-legalization) |
| 6 | DAG Combine 4 | Legal DAG, cleaned up | [DAG Combiner](#dag-combiner) |
| 7 | Instruction selection | Machine nodes | [Instruction Selection](#instruction-selection) |
| 8 | Scheduling and emission | Linear `MachineInstr`s | [Scheduling and MIR Emission](#scheduling-emission) |

The exact order, the traversal each phase uses and a sequence diagram are on [Pipeline, Phases and Traversal Orders](#pipeline). PHI handling spans several phases and has its own page: [PHI Node Resolution](#phi-resolution).

## Reading Guide

- New to the codebase: [Core Data Structures](#data-structures), then follow the pages in order.
- Interested in AArch64 behaviour: [AArch64 Walkthroughs](#aarch64-walkthroughs), starting with the [End-to-End Example](#end-to-end).
- Adding a pattern, combine or lowering: [Tooling, Debugging and Extending](#tooling).
